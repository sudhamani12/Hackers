function demo(){
    let x=document.getElementById('demo').demo;
    document.getElementById('demo').innerHTML="x";

}
function first(){
    let y=document.getElementById('first').first;
    document.getElementById('first').innerHTML="y";
}
